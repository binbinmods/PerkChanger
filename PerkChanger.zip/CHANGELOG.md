# 1.0.3

Minor Bug fixes

# 1.0.2

Updated Essentials Compatibility

# 1.0.1

Minor Bug fix

# 1.0.0

Initial testing release.
