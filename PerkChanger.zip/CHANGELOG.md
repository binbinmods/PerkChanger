# 0.1.2

Fixed a bug with Resources not being consumed when you should spend them

# 0.1.1

Fixed a bug with the Resource/Exp multipliers not applying.

Added a post-combat heal option.

# 0.1.0

Initial testing release.
